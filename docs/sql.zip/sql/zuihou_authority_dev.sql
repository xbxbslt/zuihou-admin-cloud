/*
 Navicat Premium Data Transfer

 Source Server         : 127.0.0.1
 Source Server Type    : MySQL
 Source Server Version : 50722
 Source Host           : 127.0.0.1:3306
 Source Schema         : zuihou_authority_dev

 Target Server Type    : MySQL
 Target Server Version : 50722
 File Encoding         : 65001

 Date: 01/09/2019 22:24:40
*/

use zuihou_authority_dev;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for c_auth_application
-- ----------------------------
DROP TABLE IF EXISTS `c_auth_application`;
CREATE TABLE `c_auth_application` (
  `id` bigint(20) NOT NULL COMMENT 'ID',
  `index_url` varchar(100) DEFAULT '' COMMENT '首页访问地址',
  `name` varchar(20) DEFAULT '' COMMENT '应用名称',
  `logo_url` varchar(255) DEFAULT '' COMMENT '应用logo',
  `describe_` varchar(200) DEFAULT '' COMMENT '功能描述',
  `code` varchar(20) NOT NULL COMMENT '应用编码\r\n必须唯一',
  `sort_value` int(11) DEFAULT '1' COMMENT '序号',
  `is_enable` bit(1) DEFAULT b'1' COMMENT '是否启用',
  `icp_code` varchar(32) DEFAULT '' COMMENT 'ICP备案号',
  `title_icon` varchar(255) DEFAULT '' COMMENT '标题logo',
  `support_unit` varchar(32) DEFAULT '' COMMENT '技术支持单位',
  `common_record` varchar(32) DEFAULT '' COMMENT '公网备案号',
  `create_user` bigint(20) DEFAULT NULL COMMENT '创建人id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint(20) DEFAULT NULL COMMENT '更新人id',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `un_code_` (`code`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='应用';

-- ----------------------------
-- Records of c_auth_application
-- ----------------------------
BEGIN;
INSERT INTO `c_auth_application` VALUES (1, 'http://127.0.0.1/zuihou-center', '系统综合平台', '', '', '10000', 1, b'1', '', '', '', '', 1, '2018-04-13 09:33:12', 1, '2018-04-13 09:33:12');
INSERT INTO `c_auth_application` VALUES (2, 'http:/127.0.0.1/zuihou/authority', '权限管理系统', '', '', '10001', 2, b'1', '', '', '', '', 1, '2018-04-13 19:12:09', 1, '2018-04-13 19:12:09');
INSERT INTO `c_auth_application` VALUES (3, 'http://127.0.0.1/zuihou/file', '文件管理系统', '', '', '10002', 3, b'1', '', '', NULL, '', 1, '2018-04-13 09:33:12', 1, '2018-05-09 10:15:05');
INSERT INTO `c_auth_application` VALUES (4, 'http://127.0.0.1/zuihou/msgs', '消息管理系统', '', '', '10003', 4, b'1', '', '', NULL, '', 1, '2018-04-13 09:33:12', 1, '2018-04-13 09:33:12');
COMMIT;

-- ----------------------------
-- Table structure for c_auth_menu
-- ----------------------------
DROP TABLE IF EXISTS `c_auth_menu`;
CREATE TABLE `c_auth_menu` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `name` varchar(20) NOT NULL DEFAULT '' COMMENT '菜单名称',
  `describe_` varchar(200) DEFAULT '' COMMENT '功能描述',
  `code` varchar(255) DEFAULT '' COMMENT '资源编码',
  `is_public` bit(1) DEFAULT b'0' COMMENT '是否公开菜单\r\n就是无需分配就可以访问的。所有人可见',
  `href` varchar(255) DEFAULT '' COMMENT '资源路径',
  `target` varchar(9) DEFAULT 'SELF' COMMENT '打开方式\r\n#TargetType{SELF:_self,相同框架;TOP:_top,当前页;BLANK:_blank,新建窗口;PAREN:_parent,父窗口}',
  `is_enable` bit(1) DEFAULT b'1' COMMENT '是否启用',
  `sort_value` int(11) DEFAULT '1' COMMENT '排序',
  `icon` varchar(255) DEFAULT '' COMMENT '菜单图标',
  `group_` varchar(20) DEFAULT '' COMMENT '菜单分组',
  `parent_id` bigint(20) DEFAULT '0' COMMENT '父级菜单id',
  `create_user` bigint(20) DEFAULT NULL COMMENT '创建人id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint(20) DEFAULT NULL COMMENT '更新人id',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `UN_CODE` (`code`) USING BTREE COMMENT '编码唯一'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='菜单';

-- ----------------------------
-- Records of c_auth_menu
-- ----------------------------
BEGIN;
INSERT INTO `c_auth_menu` VALUES (101, '权限管理', '111', 'authorityManage', b'1', 'authManage', 'SELF', b'1', 2, 'el-icon-lock', NULL, 0, 1, '2019-07-27 11:48:49', 1, '2019-07-25 15:40:33');
INSERT INTO `c_auth_menu` VALUES (102, '用户中心', '用户中心一级目录', 'userCenter', b'1', 'userCenter', 'SELF', b'1', 1, 'el-icon-user-solid', NULL, 0, 1, '2019-07-25 15:35:12', 1, '2019-07-25 15:35:12');
INSERT INTO `c_auth_menu` VALUES (103, '基础配置', NULL, 'baseConfig', b'1', 'baseConfig', 'SELF', b'1', 3, 'el-icon-user-solid', NULL, 0, 1, NULL, 1, NULL);
INSERT INTO `c_auth_menu` VALUES (104, '开发者管理', NULL, 'developerManage', b'1', 'developerManage', 'SELF', b'1', 4, 'el-icon-user-solid', NULL, 0, 1, NULL, NULL, NULL);
INSERT INTO `c_auth_menu` VALUES (105, '消息中心', NULL, 'msgsCenter', b'1', 'msgsCenter', 'SELF', b'1', 5, 'el-icon-user-solid', NULL, 0, 1, NULL, NULL, NULL);
INSERT INTO `c_auth_menu` VALUES (106, '短信中心', NULL, 'smsCenter', b'1', 'smsCenter', 'SELF', b'1', 6, 'el-icon-user-solid', NULL, 0, 1, NULL, NULL, NULL);
INSERT INTO `c_auth_menu` VALUES (107, '文件中心', NULL, 'fileCenter', b'1', 'fileCenter', 'SELF', b'1', 7, 'el-icon-user-solid', NULL, 0, 1, NULL, NULL, NULL);
INSERT INTO `c_auth_menu` VALUES (603976297063910529, '菜单配置', '菜单配置', 'menuManage', b'1', 'menuManage', 'SELF', b'1', 1, NULL, NULL, 101, 1, '2019-07-25 15:46:11', 1, '2019-07-25 15:46:11');
INSERT INTO `c_auth_menu` VALUES (603981723864141121, '角色管理', '角色管理菜单', 'roleManage', b'1', 'roleManage', 'SELF', b'1', 2, NULL, NULL, 101, 1, '2019-07-25 16:07:45', 1, '2019-07-25 16:07:45');
INSERT INTO `c_auth_menu` VALUES (603982542332235201, '组织管理', NULL, 'deptManage', b'1', 'deptManage', 'SELF', b'1', 1, NULL, NULL, 102, 1, '2019-07-25 16:11:00', 1, '2019-07-25 16:11:00');
INSERT INTO `c_auth_menu` VALUES (603982713849908801, '岗位管理', NULL, 'stationManage', b'1', 'stationManage', 'SELF', b'1', 2, NULL, NULL, 102, 1, '2019-07-25 16:11:41', 1, '2019-07-25 16:11:41');
INSERT INTO `c_auth_menu` VALUES (603983082961243905, '用户管理', NULL, 'userManage', b'1', 'userManage', 'SELF', b'1', 3, NULL, NULL, 102, 1, '2019-07-25 16:13:09', 1, '2019-07-25 16:13:09');
INSERT INTO `c_auth_menu` VALUES (605078371293987105, '数据字典维护', NULL, 'dictManage', b'1', 'dictManage', 'SELF', b'1', 1, NULL, NULL, 103, 1, '2019-07-28 16:45:26', 1, '2019-07-28 16:45:26');
INSERT INTO `c_auth_menu` VALUES (605078463069552993, '地区信息维护', NULL, 'areaManage', b'1', 'areaManage', 'SELF', b'1', 2, NULL, NULL, 103, 1, '2019-07-28 16:45:48', 1, '2019-07-28 16:45:48');
INSERT INTO `c_auth_menu` VALUES (605078538881597857, '服务管理', NULL, 'serviceManage', b'1', 'serviceManage', 'SELF', b'1', 1, NULL, NULL, 104, 1, '2019-07-28 16:46:06', 1, '2019-07-28 16:46:06');
INSERT INTO `c_auth_menu` VALUES (605078672772170209, '操作日志', NULL, 'optLog', b'1', 'optLog', 'SELF', b'1', 2, NULL, NULL, 104, 1, '2019-07-28 16:46:38', 1, '2019-07-28 16:46:38');
INSERT INTO `c_auth_menu` VALUES (605078979149300257, '数据库监控', NULL, 'dbMonitor', b'1', 'dbMonitor', 'SELF', b'1', 3, NULL, NULL, 104, 1, '2019-07-28 16:47:51', 1, '2019-07-28 16:47:51');
INSERT INTO `c_auth_menu` VALUES (605079239015793249, 'swagger在线文档', NULL, 'swagger_api', b'1', 'http://wzroom.cn/api/gate/doc.html?showMenuApi=1&showDes=1&plus=1&cache=1&cacheApi=1&lang=zh', 'SELF', b'1', 4, NULL, NULL, 104, 1, '2019-07-28 16:48:53', 1, '2019-07-28 16:48:53');
INSERT INTO `c_auth_menu` VALUES (605079411338773153, '注册中心', NULL, 'eureka_center', b'1', 'http://wzroom.cn/zuihou-eureka/', 'SELF', b'1', 5, NULL, NULL, 104, 1, '2019-07-28 16:49:34', 1, '2019-07-28 16:49:34');
INSERT INTO `c_auth_menu` VALUES (605079545585861345, '缓存监控', NULL, 'redis_monitor', b'1', NULL, 'SELF', b'1', 6, NULL, NULL, 104, 1, '2019-07-28 16:50:06', 1, '2019-07-28 16:50:06');
INSERT INTO `c_auth_menu` VALUES (605079658416833313, '服务器监控', NULL, 'server_monitor', b'1', NULL, 'SELF', b'1', 7, NULL, NULL, 104, 1, '2019-07-28 16:50:33', 1, '2019-07-28 16:50:33');
INSERT INTO `c_auth_menu` VALUES (605079751035454305, '消息推送', NULL, 'msgs_push', b'1', 'sendMsgs', 'SELF', b'1', 1, NULL, NULL, 105, 1, '2019-07-28 16:50:55', 1, '2019-09-01 19:36:48');
INSERT INTO `c_auth_menu` VALUES (605080023753294753, '我的消息', NULL, 'msgs_list', b'1', 'myMsgs', 'SELF', b'1', 2, NULL, NULL, 105, 1, '2019-07-28 16:52:00', 1, '2019-09-01 19:36:56');
INSERT INTO `c_auth_menu` VALUES (605080107379327969, '账号配置', NULL, 'account_config', b'1', NULL, 'SELF', b'1', 1, NULL, NULL, 106, 1, '2019-07-28 16:52:20', 1, '2019-07-28 16:52:20');
INSERT INTO `c_auth_menu` VALUES (605080182910354465, '模板配置', NULL, 'template_config', b'1', NULL, 'SELF', b'1', 2, NULL, NULL, 106, 1, '2019-07-28 16:52:38', 1, '2019-07-28 16:52:38');
INSERT INTO `c_auth_menu` VALUES (605080359394083937, '短信管理', NULL, 'sms_send', b'1', NULL, 'SELF', b'1', 3, NULL, NULL, 106, 1, '2019-07-28 16:53:20', 1, '2019-07-28 16:54:02');
INSERT INTO `c_auth_menu` VALUES (605080648767505601, '附件列表', NULL, 'attachment_list', b'1', NULL, 'SELF', b'1', 4, NULL, NULL, 107, 1, '2019-07-28 16:54:29', 1, '2019-07-28 16:54:29');
INSERT INTO `c_auth_menu` VALUES (605080682221274369, '文件列表', NULL, 'file_list', b'1', NULL, 'SELF', b'1', 2, NULL, NULL, 107, 1, '2019-07-28 16:54:37', 1, '2019-07-28 16:54:37');
INSERT INTO `c_auth_menu` VALUES (605080816296396097, '定时调度中心', NULL, 'jobs_center', b'1', 'http://wzroom.cn/zuihou-jobs-server', 'SELF', b'1', 8, NULL, NULL, 104, 1, '2019-07-28 16:55:09', 1, '2019-07-28 16:55:09');
INSERT INTO `c_auth_menu` VALUES (605424535633666945, '接口查询', '', 'apiView', b'1', 'apiView', 'SELF', b'1', 2, '', '', 104, 1, '2019-07-29 15:40:58', 1, '2019-07-29 15:40:58');
COMMIT;

-- ----------------------------
-- Table structure for c_auth_micro_service
-- ----------------------------
DROP TABLE IF EXISTS `c_auth_micro_service`;
CREATE TABLE `c_auth_micro_service` (
  `id` bigint(20) NOT NULL,
  `name` varchar(20) DEFAULT '' COMMENT '服务名称',
  `describe_` varchar(100) DEFAULT '' COMMENT '服务描述',
  `eureka_code` varchar(100) DEFAULT '' COMMENT 'eureka编码\r\n就是服务注册到eureka后，他的application name',
  `swagger_url` varchar(255) DEFAULT '' COMMENT 'swagger地址',
  `sort_value` int(11) DEFAULT '1' COMMENT '排序',
  `create_user` bigint(20) DEFAULT NULL COMMENT '创建人id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint(20) DEFAULT NULL COMMENT '更新人id',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='服务表';

-- ----------------------------
-- Records of c_auth_micro_service
-- ----------------------------
BEGIN;
INSERT INTO `c_auth_micro_service` VALUES (611507704891965537, '消息服务', '消息服务', 'zuihou-file-server', 'http://192.168.1.34:8765/swagger-resources', 1, 1, '2019-08-15 10:33:18', 1, '2019-08-15 10:34:33');
INSERT INTO `c_auth_micro_service` VALUES (611507705101680769, '消息服务', '消息服务', 'zuihou-msgs-server', 'http://192.168.1.34:8768/swagger-resources', 1, 1, '2019-08-15 10:33:18', 1, '2019-08-15 10:34:33');
INSERT INTO `c_auth_micro_service` VALUES (611507705131040929, '消息服务', '消息服务', 'zuihou-zuul-server', 'http://192.168.1.34:8760/swagger-resources', 1, 1, '2019-08-15 10:33:18', 1, '2019-08-15 10:34:33');
INSERT INTO `c_auth_micro_service` VALUES (611507990473736417, '权限服务', '权限服务', 'zuihou-authority-server', 'http://192.168.1.34:8764/swagger-resources', 1, 1, '2019-08-15 10:34:26', 1, '2019-08-15 10:34:33');
COMMIT;

-- ----------------------------
-- Table structure for c_auth_resource
-- ----------------------------
DROP TABLE IF EXISTS `c_auth_resource`;
CREATE TABLE `c_auth_resource` (
  `id` bigint(20) NOT NULL COMMENT 'ID',
  `code` varchar(255) DEFAULT '' COMMENT '资源编码\n规则：\n链接：\n数据列：\n按钮：',
  `resource_type` varchar(10) NOT NULL DEFAULT 'BUTTON' COMMENT '资源类型 \n#ResourceType{BUTTON:按钮;URI:链接;COLUMN:字段;}',
  `name` varchar(255) NOT NULL DEFAULT '' COMMENT '接口名称',
  `micro_service_id` bigint(20) DEFAULT NULL COMMENT '服务ID\n#c_auth_micro_service',
  `menu_id` bigint(20) DEFAULT NULL COMMENT '菜单ID\n#c_auth_menu',
  `menu_name` varchar(255) DEFAULT '' COMMENT '菜单名称',
  `tags` varchar(255) DEFAULT '' COMMENT '类标签',
  `describe_` varchar(255) DEFAULT '' COMMENT '接口描述',
  `uri` varchar(150) DEFAULT '' COMMENT '地址',
  `http_method` varchar(7) DEFAULT 'GET' COMMENT '请求方式\r\n#HttpMethod{GET:GET请求;POST:POST请求;PUT:PUT请求;DELETE:DELETE请求;PATCH:PATCH请求;TRACE:TRACE请求;HEAD:HEAD请求;OPTIONS:OPTIONS请求;}\n         ',
  `deprecated` bit(1) DEFAULT b'0' COMMENT '是否过时',
  `create_user` bigint(20) DEFAULT NULL COMMENT '创建人id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint(20) DEFAULT NULL COMMENT '更新人id',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `UN_CODE` (`code`) COMMENT '编码唯一',
  UNIQUE KEY `UN_URI` (`resource_type`,`micro_service_id`,`http_method`,`uri`) USING BTREE COMMENT 'URI唯一'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='资源';

-- ----------------------------
-- Records of c_auth_resource
-- ----------------------------
BEGIN;
INSERT INTO `c_auth_resource` VALUES (1, '1', 'BUTTON', '新增%一个', NULL, NULL, NULL, '/api', '1', '/2', 'GET', b'0', 1, NULL, 0, '2019-07-18 22:38:18');
INSERT INTO `c_auth_resource` VALUES (2, '2', 'BUTTON', '新增2', NULL, NULL, NULL, '123', '', '1', 'POST', b'0', NULL, NULL, NULL, NULL);
INSERT INTO `c_auth_resource` VALUES (605419349011857633, '_area_{id}', 'URI', '删除地区表', 601003256973361185, NULL, '', '地区表', '根据id物理删除地区表', '/area/{id}', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349091549473, '_dictionaryItem', 'URI', '修改字典项', 601003256973361185, NULL, '', '字典项', '修改字典项不为空的字段', '/dictionaryItem', 'POST', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349137686881, '_dictionaryItem_page', 'URI', '分页查询字典项', 601003256973361185, NULL, '', '字典项', '分页查询字典项', '/dictionaryItem/page', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349158658433, '_dictionary', 'URI', '修改字典目录', 601003256973361185, NULL, '', '字典目录', '修改字典目录不为空的字段', '/dictionary', 'POST', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349200601537, '_optLog', 'URI', '保存系统日志', 601003256973361185, NULL, '', '系统日志', '保存系统日志不为空的字段', '/optLog', 'POST', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349225767393, '_dictionary_page', 'URI', '分页查询字典目录', 601003256973361185, NULL, '', '字典目录', '分页查询字典目录', '/dictionary/page', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349250933249, '_dictionaryItem_codes', 'URI', '根据字典编码查询字典条目的map集合', 601003256973361185, NULL, '', '字典项', '根据字典编码查询字典条目的map集合', '/dictionaryItem/codes', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349271904801, '_dictionaryItem_{id}', 'URI', '删除字典项', 601003256973361185, NULL, '', '字典项', '根据id物理删除字典项', '/dictionaryItem/{id}', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349322236513, '_area_page', 'URI', '分页查询地区表', 601003256973361185, NULL, '', '地区表', '分页查询地区表', '/area/page', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349347402369, '_area', 'URI', '修改地区表', 601003256973361185, NULL, '', '地区表', '修改地区表不为空的字段', '/area', 'POST', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349393539777, '_optLog_page', 'URI', '分页查询系统日志', 601003256973361185, NULL, '', '系统日志', '分页查询系统日志', '/optLog/page', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349422899937, '_optLog_{id}', 'URI', '删除系统日志', 601003256973361185, NULL, '', '系统日志', '根据id物理删除系统日志', '/optLog/{id}', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349473231649, '_dictionary_{id}', 'URI', '删除字典目录', 601003256973361185, NULL, '', '字典目录', '根据id物理删除字典目录', '/dictionary/{id}', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349775221601, '_application', 'URI', '修改应用', 601003256973361185, NULL, '', '应用', '修改应用不为空的字段', '/application', 'POST', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349821359009, '_microService_parse', 'URI', '解析接口', 601003256973361185, NULL, '', '服务表', '解析已经启动的服务的全部接口', '/microService/parse', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349846524865, '_resource', 'URI', '修改资源', 601003256973361185, NULL, '', '资源', '修改资源不为空的字段', '/resource', 'POST', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349926216737, '_resource_{id}', 'URI', '删除资源', 601003256973361185, NULL, '', '资源', '根据id物理删除资源', '/resource/{id}', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419349976548449, '_microService_page', 'URI', '分页查询服务表', 601003256973361185, NULL, '', '服务表', '分页查询服务表', '/microService/page', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350010102913, '_menu', 'URI', '修改菜单', 601003256973361185, NULL, '', '菜单', '修改菜单不为空的字段', '/menu', 'POST', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350089794785, '_application_page', 'URI', '分页查询应用', 601003256973361185, NULL, '', '应用', '分页查询应用', '/application/page', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350110766337, '_user_{id}', 'URI', '删除用户', 601003256973361185, NULL, '', '用户', '根据id物理删除用户', '/user/{id}', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350156903745, '_roleAuthority_{roleId}', 'URI', '查询指定角色关联的菜单和资源', 601003256973361185, NULL, '', '角色的资源', '查询指定角色关联的菜单和资源', '/roleAuthority/{roleId}', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350194652513, '_anno_login', 'URI', '验证登录并刷新token', 601003256973361185, NULL, '', '用户级别的token管理', '验证登录并刷新token', '/anno/login', 'POST', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350228206977, '_anno_token', 'URI', '刷新并获取token', 601003256973361185, NULL, '', '用户级别的token管理', '刷新并获取token', '/anno/token', 'GET', b'1', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350253372833, '_menu_{id}', 'URI', '删除菜单', 601003256973361185, NULL, '', '菜单', '根据id物理删除菜单', '/menu/{id}', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350303704545, '_role_menu', 'URI', '给角色配置权限', 601003256973361185, NULL, '', '角色', '给角色配置权限', '/role/menu', 'POST', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350333064705, '_user_ds_{id}', 'URI', '查询用户权限范围', 601003256973361185, NULL, '', '用户', '根据用户id，查询用户权限范围', '/user/ds/{id}', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350358230561, '_resource_page', 'URI', '分页查询资源', 601003256973361185, NULL, '', '资源', '分页查询资源', '/resource/page', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350379202113, '_user_page', 'URI', '分页查询用户', 601003256973361185, NULL, '', '用户', '分页查询用户', '/user/page', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:50');
INSERT INTO `c_auth_resource` VALUES (605419350400173665, '_user_role_{roleId}', 'URI', '查询角色的已关联用户', 601003256973361185, NULL, '', '用户', '查询角色的已关联用户', '/user/role/{roleId}', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350421145217, '_menu_page', 'URI', '分页查询菜单', 601003256973361185, NULL, '', '菜单', '分页查询菜单', '/menu/page', 'GET', b'0', 1, '2019-07-29 15:20:21', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350442116769, '_role_page', 'URI', '分页查询角色', 601003256973361185, NULL, '', '角色', '分页查询角色', '/role/page', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350463088321, '_anno_verify', 'URI', '验证token', 601003256973361185, NULL, '', '用户级别的token管理', '验证token', '/anno/verify', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350484059873, '_microService_{id}', 'URI', '删除服务表', 601003256973361185, NULL, '', '服务表', '根据id物理删除服务表', '/microService/{id}', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350526002977, '_menu_tree', 'URI', '查询系统所有的菜单', 601003256973361185, NULL, '', '菜单', '查询系统所有的菜单', '/menu/tree', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350551168833, '_role_user', 'URI', '给角色分配用户', 601003256973361185, NULL, '', '角色', '给角色分配用户', '/role/user', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350572140385, '_role', 'URI', '修改角色', 601003256973361185, NULL, '', '角色', '修改角色不为空的字段', '/role', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350618277793, '_application_{id}', 'URI', '删除应用', 601003256973361185, NULL, '', '应用', '根据id物理删除应用', '/application/{id}', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350664415201, '_microService_sync', 'URI', '同步服务', 601003256973361185, NULL, '', '服务表', '从注册中心上拉取已注册的服务，进行存储', '/microService/sync', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350689581057, '_role_{id}', 'URI', '删除角色', 601003256973361185, NULL, '', '角色', '根据id物理删除角色', '/role/{id}', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350735718465, '_user_anno_id_{id}', 'URI', '查询用户详细', 601003256973361185, NULL, '', '用户', '查询用户详细', '/user/anno/id/{id}', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350760884321, '_user', 'URI', '修改用户', 601003256973361185, NULL, '', '用户', '修改用户不为空的字段', '/user', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350807021729, '_microService', 'URI', '修改服务表', 601003256973361185, NULL, '', '服务表', '修改服务表不为空的字段', '/microService', 'PUT', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350941239489, '_org_tree', 'URI', '查询系统所有的组织树', 601003256973361185, NULL, '', '组织', '查询系统所有的组织树', '/org/tree', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419350970599649, '_org', 'URI', '修改组织', 601003256973361185, NULL, '', '组织', '修改组织不为空的字段', '/org', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351025125665, '_station', 'URI', '修改岗位', 601003256973361185, NULL, '', '岗位', '修改岗位不为空的字段', '/station', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351079651681, '_station_{id}', 'URI', '删除岗位', 601003256973361185, NULL, '', '岗位', '根据id物理删除岗位', '/station/{id}', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351209675169, '_station_page', 'URI', '分页查询岗位', 601003256973361185, NULL, '', '岗位', '分页查询岗位', '/station/page', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351234841025, '_org_{id}', 'URI', '删除组织', 601003256973361185, NULL, '', '组织', '根据id物理删除组织', '/org/{id}', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351272589825, '_org_move', 'URI', '移动', 601003256973361185, NULL, '', '组织', '修改不为空的字段', '/org/move', 'PUT', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351293561377, '_org_page', 'URI', '分页查询组织', 601003256973361185, NULL, '', '组织', '分页查询组织', '/org/page', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351662660161, '_valid_obj_get2', 'URI', 'objGet2', 601003256973361185, NULL, '', '验证', NULL, '/valid/obj/get2', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351696214625, '_valid_obj_get3', 'URI', 'objGet3', 601003256973361185, NULL, '', '验证', NULL, '/valid/obj/get3', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351721380481, '_valid1_obj_get1', 'URI', 'objGet1', 601003256973361185, NULL, '', '验证1', NULL, '/valid1/obj/get1', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351750740641, '_valid1_obj_get2', 'URI', 'objGet2', 601003256973361185, NULL, '', '验证1', NULL, '/valid1/obj/get2', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351775906497, '_valid_obj_get6', 'URI', 'objGet6', 601003256973361185, NULL, '', '验证', NULL, '/valid/obj/get6', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351801072353, '_test', 'URI', 'save', 601003256973361185, NULL, '', '测试类', NULL, '/test', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351830432513, '_valid_obj_get4', 'URI', 'objGet4', 601003256973361185, NULL, '', '验证', NULL, '/valid/obj/get4', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351855598369, '_valid_obj_get5', 'URI', 'objGet5', 601003256973361185, NULL, '', '验证', NULL, '/valid/obj/get5', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351884958529, '_test_get3', 'URI', 'get3', 601003256973361185, NULL, '', '测试类', NULL, '/test/get3', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351905930081, '_date_post1', 'URI', 'bodyPos1', 601003256973361185, NULL, '', '时间类型验证器', NULL, '/date/post1', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351931095937, '_test_post2', 'URI', 'post2', 601003256973361185, NULL, '', '测试类', NULL, '/test/post2', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351956261793, '_valid2_requestParam_get1', 'URI', 'paramGet1', 601003256973361185, NULL, '', '验证2', NULL, '/valid2/requestParam/get1', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419351985621953, '_valid3_post3', 'URI', 'bodyPost3', 601003256973361185, NULL, '', '验证3', NULL, '/valid3/post3', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352006593505, '_valid2_requestParam_get2', 'URI', 'paramGet2', 601003256973361185, NULL, '', '验证2', NULL, '/valid2/requestParam/get2', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352031759361, '_valid3_post4', 'URI', 'bodyPost4', 601003256973361185, NULL, '', '验证3', NULL, '/valid3/post4', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352052730913, '_valid3_post1', 'URI', 'bodyPos1', 601003256973361185, NULL, '', '验证3', NULL, '/valid3/post1', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352073702465, '_valid3_post2', 'URI', 'bodyPost2', 601003256973361185, NULL, '', '验证3', NULL, '/valid3/post2', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352094674017, '_valid2_requestParam_get5', 'URI', 'paramGet5', 601003256973361185, NULL, '', '验证2', NULL, '/valid2/requestParam/get5', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352115645569, '_valid3_post7', 'URI', 'bodyPost7', 601003256973361185, NULL, '', '验证3', NULL, '/valid3/post7', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352136617121, '_valid2_requestParam_get6', 'URI', 'paramGet6', 601003256973361185, NULL, '', '验证2', NULL, '/valid2/requestParam/get6', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352165977281, '_valid2_requestParam_get3', 'URI', 'paramGet3', 601003256973361185, NULL, '', '验证2', NULL, '/valid2/requestParam/get3', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352195337441, '_valid3_post5', 'URI', 'bodyPost5', 601003256973361185, NULL, '', '验证3', NULL, '/valid3/post5', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352224697601, '_valid2_requestParam_get4', 'URI', 'paramGet4', 601003256973361185, NULL, '', '验证2', NULL, '/valid2/requestParam/get4', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352254057761, '_valid3_post6', 'URI', 'bodyPost6', 601003256973361185, NULL, '', '验证3', NULL, '/valid3/post6', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352275029313, '_valid_requestParam_get2', 'URI', 'paramGet2', 601003256973361185, NULL, '', '验证', NULL, '/valid/requestParam/get2', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352304389473, '_date_post2', 'URI', 'bodyPos2', 601003256973361185, NULL, '', '时间类型验证器', NULL, '/date/post2', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352329555329, '_valid_requestBody_post', 'URI', 'bodyPost', 601003256973361185, NULL, '', '验证', NULL, '/valid/requestBody/post', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352346332577, '_test_get', 'URI', 'get2', 601003256973361185, NULL, '', '测试类', NULL, '/test/get', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352367304129, '_valid_requestParam_get', 'URI', 'paramGet', 601003256973361185, NULL, '', '验证', NULL, '/valid/requestParam/get', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352384081377, '_valid3_post61', 'URI', 'bodyPost61', 601003256973361185, NULL, '', '验证3', NULL, '/valid3/post61', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352405052929, '_date_get1', 'URI', 'get', 601003256973361185, NULL, '', '时间类型验证器', NULL, '/date/get1', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352426024481, '_valid3_post62', 'URI', 'bodyPost62', 601003256973361185, NULL, '', '验证3', NULL, '/valid3/post62', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352455384641, '_date_get2', 'URI', 'get2', 601003256973361185, NULL, '', '时间类型验证器', NULL, '/date/get2', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352476356193, '_valid1_obj_get32', 'URI', 'objGet32', 601003256973361185, NULL, '', '验证1', NULL, '/valid1/obj/get32', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352493133441, '_test_{id}', 'URI', 'get', 601003256973361185, NULL, '', '测试类', NULL, '/test/{id}', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352514104993, '_valid1_obj_get31', 'URI', 'objGet31', 601003256973361185, NULL, '', '验证1', NULL, '/valid1/obj/get31', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352551853761, '_valid_requestBody_post6', 'URI', 'bodyPost6', 601003256973361185, NULL, '', '验证', NULL, '/valid/requestBody/post6', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352581213921, '_valid1_obj_get5', 'URI', 'objGet5', 601003256973361185, NULL, '', '验证1', NULL, '/valid1/obj/get5', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352610574081, '_att_upload', 'URI', '附件上传', 601003256973361185, NULL, '', '跨服务附件上传', '附件上传', '/att/upload', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352635739937, '_valid1_obj_get3', 'URI', 'objGet3', 601003256973361185, NULL, '', '验证1', NULL, '/valid1/obj/get3', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352669294401, '_valid_requestBody_post5', 'URI', 'bodyPost5', 601003256973361185, NULL, '', '验证', NULL, '/valid/requestBody/post5', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352711237473, '_valid1_obj_get4', 'URI', 'objGet4', 601003256973361185, NULL, '', '验证1', NULL, '/valid1/obj/get4', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352744791937, '_valid_requestBody_post3', 'URI', 'bodyPost3', 601003256973361185, NULL, '', '验证', NULL, '/valid/requestBody/post3', 'POST', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352795123617, '_valid1_obj_get7', 'URI', 'objGet6', 601003256973361185, NULL, '', '验证1', NULL, '/valid1/obj/get7', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352837066689, '_valid1_obj_get8', 'URI', 'objGet8', 601003256973361185, NULL, '', '验证1', NULL, '/valid1/obj/get8', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-07-29 15:20:51');
INSERT INTO `c_auth_resource` VALUES (605419352929341409, '_enums', 'URI', '获取当前系统所有枚举', 601003256973361185, NULL, '', '公共Controller', '获取当前系统所有枚举', '/enums', 'GET', b'0', 1, '2019-07-29 15:20:22', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140155863361, '_attachment_download_{bizType}_{bizId}', 'URI', '获取图片', 611507704891965537, NULL, '', '附件', '根据业务类型和业务id在前端img标签中回显图片附件， 但存在多个附件时，默认显示第一个图片', '/attachment/download/{bizType}/{bizId}', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140210389345, '_statistics_downTop20', 'URI', '云盘首页个人文件下载数量排行', 611507704891965537, NULL, '', '统计接口', '云盘首页个人文件下载数量排行', '/statistics/downTop20', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140243943809, '_attachment_upload', 'URI', '附件上传', 611507704891965537, NULL, '', '附件', '附件上传', '/attachment/upload', 'POST', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140285886881, '_file_download', 'URI', '下载一个文件或多个文件打包下载', 611507704891965537, NULL, '', '文件表', '下载一个文件或多个文件打包下载', '/file/download', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140319441345, '_attachment', 'URI', '删除文件', 611507704891965537, NULL, '', '附件', '删除文件', '/attachment', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140390744577, '_attachment_page', 'URI', '分页查询附件', 611507704891965537, NULL, '', '附件', '分页查询附件', '/attachment/page', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140424299041, '_chunk_check', 'URI', '续传接口，检查每个分片存不存在', 611507704891965537, NULL, '', '文件续传+秒传功能，所有方法均需要webuploder.js插件进行配合使用， 且4个方法需要配合使用，单核接口没有意义', '断点续传功能检查分片是否存在， 已存在的分片无需重复上传， 达到续传效果', '/chunk/check', 'POST', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140470436417, '_statistics', 'URI', '按照时间统计各种类型的文件的数量和大小', 611507704891965537, NULL, '', '统计接口', '按照时间统计各种类型的文件的数量和大小 不指定时间，默认查询一个月', '/statistics', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140503990881, '_attachment_download', 'URI', '根据文件id打包下载', 611507704891965537, NULL, '', '附件', '根据附件id下载多个打包的附件', '/attachment/download', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140541739649, '_chunk_merge', 'URI', '分片合并', 611507704891965537, NULL, '', '文件续传+秒传功能，所有方法均需要webuploder.js插件进行配合使用， 且4个方法需要配合使用，单核接口没有意义', '所有分片上传成功后，调用该接口对分片进行合并', '/chunk/merge', 'POST', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140575294113, '_file', 'URI', '修改文件/文件夹名称', 611507704891965537, NULL, '', '文件表', '修改文件/文件夹名称', '/file', 'POST', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140675957505, '_statistics_down', 'URI', '按照时间统计下载数量', 611507704891965537, NULL, '', '统计接口', '按照时间统计下载数量 不指定时间，默认查询一个月', '/statistics/down', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140709511969, '_statistics_type', 'URI', '按照类型，统计各种类型的 大小和数量', 611507704891965537, NULL, '', '统计接口', '按照类型，统计当前登录人各种类型的大小和数量', '/statistics/type', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140751455041, '_attachment_download_url', 'URI', '根据url下载文件(不推荐)', 611507704891965537, NULL, '', '附件', '根据文件的url下载文件(不推荐使用，若要根据url下载，请执行通过nginx)', '/attachment/download/url', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140789203809, '_statistics_overview', 'URI', '云盘首页数据概览', 611507704891965537, NULL, '', '统计接口', '云盘首页数据概览', '/statistics/overview', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140822758273, '_file_page', 'URI', '分页查询文件', 611507704891965537, NULL, '', '文件表', '获取文件分页', '/file/page', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140860507041, '_chunk_md5', 'URI', '秒传接口，上传文件前先验证， 存在则启动秒传', 611507704891965537, NULL, '', '文件续传+秒传功能，所有方法均需要webuploder.js插件进行配合使用， 且4个方法需要配合使用，单核接口没有意义', '前端通过webUploader获取文件md5，上传前的验证', '/chunk/md5', 'POST', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140894061505, '_attachment_biz', 'URI', '根据业务类型或业务id删除文件', 611507704891965537, NULL, '', '附件', '根据业务类型或业务id删除文件', '/attachment/biz', 'DELETE', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140923421665, '_chunk_upload', 'URI', '分片上传', 611507704891965537, NULL, '', '文件续传+秒传功能，所有方法均需要webuploder.js插件进行配合使用， 且4个方法需要配合使用，单核接口没有意义', '前端通过webUploader获取截取分片， 然后逐个上传', '/chunk/upload', 'POST', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140956976129, '_attachment_download_biz', 'URI', '根据业务类型/业务id打包下载', 611507704891965537, NULL, '', '附件', '根据业务id下载一个文件或多个文件打包下载', '/attachment/download/biz', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508140990530593, '_file_ids', 'URI', '根据Ids进行文件删除', 611507704891965537, NULL, '', '文件表', '根据Ids进行文件删除  ', '/file/ids', 'DELETE', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508141024085057, '_attachment_{type}', 'URI', '根据业务类型或者业务id查询附件', 611507704891965537, NULL, '', '附件', '根据业务类型或者业务id查询附件', '/attachment/{type}', 'GET', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
INSERT INTO `c_auth_resource` VALUES (611508141053445217, '_file_upload', 'URI', '上传文件', 611507704891965537, NULL, '', '文件表', '上传文件 ', '/file/upload', 'POST', b'0', 1, '2019-08-15 10:35:02', 1, '2019-08-15 10:35:02');
COMMIT;

-- ----------------------------
-- Table structure for c_auth_role
-- ----------------------------
DROP TABLE IF EXISTS `c_auth_role`;
CREATE TABLE `c_auth_role` (
  `id` bigint(20) NOT NULL,
  `name` varchar(30) DEFAULT '' COMMENT '角色名称',
  `code` varchar(20) DEFAULT '' COMMENT '角色编码',
  `describe_` varchar(100) DEFAULT '' COMMENT '功能描述',
  `is_enable` bit(1) DEFAULT b'1' COMMENT '是否启用',
  `is_readonly` bit(1) DEFAULT b'0' COMMENT '是否只读角色',
  `ds_type` varchar(20) NOT NULL DEFAULT 'SELF' COMMENT '数据权限类型\n#DataScopeType{ALL:1,全部;THIS_LEVEL:2,本级;THIS_LEVEL_CHILDREN:3,本级以及子级;CUSTOMIZE:4,自定义;SELF:5,个人;}',
  `create_user` bigint(20) DEFAULT '0' COMMENT '创建人id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint(20) DEFAULT '0' COMMENT '更新人id',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `UN_CODE` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色';

-- ----------------------------
-- Records of c_auth_role
-- ----------------------------
BEGIN;
INSERT INTO `c_auth_role` VALUES (100, '超级管理员', 'SUPER_ADMIN', '系统内置超级管理员，勿删', b'1', b'1', 'THIS_LEVEL_CHILDREN', 1, '2019-06-06 13:53:56', 1, '2019-08-22 15:15:45');
INSERT INTO `c_auth_role` VALUES (614111442844518209, '123', '12343', '123', b'1', b'0', 'CUSTOMIZE', 0, '2019-08-22 14:59:38', 0, '2019-08-22 14:59:38');
COMMIT;

-- ----------------------------
-- Table structure for c_auth_role_authority
-- ----------------------------
DROP TABLE IF EXISTS `c_auth_role_authority`;
CREATE TABLE `c_auth_role_authority` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `authority_id` bigint(20) NOT NULL COMMENT '资源id\n#c_auth_resource\n#c_auth_menu',
  `authority_type` varchar(10) NOT NULL DEFAULT 'MENU' COMMENT '权限类型\n#AuthorizeType{MENU:菜单;RESOURCE:资源;}',
  `role_id` bigint(20) NOT NULL COMMENT '角色id\n#c_auth_role',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `create_user` bigint(20) DEFAULT '0' COMMENT '创建人',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色的资源';

-- ----------------------------
-- Records of c_auth_role_authority
-- ----------------------------
BEGIN;
INSERT INTO `c_auth_role_authority` VALUES (1, 1, 'MENU', 1, '2019-06-26 11:35:07', 0);
INSERT INTO `c_auth_role_authority` VALUES (2, 2, 'MENU', 1, NULL, 0);
INSERT INTO `c_auth_role_authority` VALUES (3, 3, 'MENU', 1, NULL, 0);
INSERT INTO `c_auth_role_authority` VALUES (4, 4, 'MENU', 1, NULL, 0);
INSERT INTO `c_auth_role_authority` VALUES (5, 5, 'MENU', 1, NULL, 0);
INSERT INTO `c_auth_role_authority` VALUES (6, 1, 'RESOURCE', 1, NULL, 0);
COMMIT;

-- ----------------------------
-- Table structure for c_auth_role_org
-- ----------------------------
DROP TABLE IF EXISTS `c_auth_role_org`;
CREATE TABLE `c_auth_role_org` (
  `id` bigint(20) NOT NULL COMMENT 'ID',
  `role_id` bigint(20) DEFAULT NULL COMMENT '角色ID\n#c_auth_role',
  `org_id` bigint(20) DEFAULT NULL COMMENT '部门ID\n#c_core_org',
  `create_time` datetime DEFAULT NULL,
  `create_user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色组织关系';

-- ----------------------------
-- Records of c_auth_role_org
-- ----------------------------
BEGIN;
INSERT INTO `c_auth_role_org` VALUES (614111442890655585, 614111442844518209, 100, '2019-08-22 14:59:38', 0);
INSERT INTO `c_auth_role_org` VALUES (614111442903238529, 614111442844518209, 101, '2019-08-22 14:59:38', 0);
INSERT INTO `c_auth_role_org` VALUES (614111442907432865, 614111442844518209, 102, '2019-08-22 14:59:38', 0);
INSERT INTO `c_auth_role_org` VALUES (614115501605388417, 100, 100, '2019-08-22 15:15:46', 1);
INSERT INTO `c_auth_role_org` VALUES (614115501622165665, 100, 101, '2019-08-22 15:15:46', 1);
INSERT INTO `c_auth_role_org` VALUES (614115501630554305, 100, 102, '2019-08-22 15:15:46', 1);
COMMIT;

-- ----------------------------
-- Table structure for c_auth_user
-- ----------------------------
DROP TABLE IF EXISTS `c_auth_user`;
CREATE TABLE `c_auth_user` (
  `id` bigint(20) NOT NULL COMMENT 'ID',
  `account` varchar(30) NOT NULL COMMENT '账号',
  `name` varchar(50) NOT NULL COMMENT '姓名',
  `org_id` bigint(20) DEFAULT NULL COMMENT '组织ID\n#c_core_org',
  `station_id` bigint(20) DEFAULT NULL COMMENT '岗位ID\n#c_core_station',
  `mobile` varchar(20) DEFAULT '' COMMENT '手机',
  `sex` varchar(1) DEFAULT 'M' COMMENT '性别\n#Sex{W:女;M:男}',
  `is_can_login` bit(1) DEFAULT b'1' COMMENT '是否可登陆',
  `is_delete` bit(1) DEFAULT b'0' COMMENT '删除标记',
  `photo` varchar(255) DEFAULT '' COMMENT '照片',
  `work_describe` varchar(255) DEFAULT '' COMMENT '工作描述\r\n比如：  市长、管理员、局长等等   用于登陆展示',
  `login_count` int(11) DEFAULT '0' COMMENT '登录次数\n一直累计，记录了此账号总共登录次数',
  `continuation_error_day` date DEFAULT NULL COMMENT '输入密码错误的日期\r\n比如20190102  与error_count合力实现一天输入密码错误次数限制',
  `continuation_error_count` int(11) DEFAULT '0' COMMENT '一天连续输错密码次数',
  `password_expire_time` datetime DEFAULT NULL COMMENT '密码过期时间',
  `password` varchar(64) NOT NULL DEFAULT '' COMMENT '密码',
  `create_user` bigint(20) DEFAULT '0' COMMENT '创建人id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint(20) DEFAULT '0' COMMENT '更新人id',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `UN_ACCOUNT` (`account`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户';

-- ----------------------------
-- Records of c_auth_user
-- ----------------------------
BEGIN;
INSERT INTO `c_auth_user` VALUES (1, 'zuihou', '最后', 100, 100, '1', 'M', b'1', b'0', '1', '1', 29, '2019-06-13', 0, '2019-09-07 09:56:54', 'd9d17d88918aa72834289edaf38f42e2', NULL, NULL, 0, '2019-06-04 18:29:55');
INSERT INTO `c_auth_user` VALUES (608600070866075713, '15218869970', '15218869970', 101, 101, '15218869970', 'M', b'1', b'0', '', '演示账号', 0, NULL, 0, NULL, 'e10adc3949ba59abbe56e057f20f883e', 0, '2019-08-07 09:59:24', 0, '2019-08-07 09:59:24');
COMMIT;

-- ----------------------------
-- Table structure for c_auth_user_role
-- ----------------------------
DROP TABLE IF EXISTS `c_auth_user_role`;
CREATE TABLE `c_auth_user_role` (
  `id` bigint(20) NOT NULL,
  `role_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '角色ID\n#c_auth_role',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户ID\n#c_core_accou',
  `create_user` bigint(20) DEFAULT NULL COMMENT '创建人ID',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='角色分配\r\n账号角色绑定';

-- ----------------------------
-- Records of c_auth_user_role
-- ----------------------------
BEGIN;
INSERT INTO `c_auth_user_role` VALUES (1, 100, 1, 1, NULL);
COMMIT;

-- ----------------------------
-- Table structure for c_common_dictionary
-- ----------------------------
DROP TABLE IF EXISTS `c_common_dictionary`;
CREATE TABLE `c_common_dictionary` (
  `id` bigint(20) NOT NULL,
  `code` varchar(64) NOT NULL DEFAULT '' COMMENT '编码\r\n一颗树仅仅有一个统一的编码',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '字典名称',
  `describe_` varchar(200) DEFAULT '' COMMENT '字典描述',
  `is_enable` bit(1) DEFAULT b'1' COMMENT '是否启用',
  `is_delete` bit(1) DEFAULT b'0' COMMENT '是否删除',
  `create_user` bigint(20) DEFAULT '0' COMMENT '创建人id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint(20) DEFAULT '0' COMMENT '更新人id',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='字典目录';

-- ----------------------------
-- Records of c_common_dictionary
-- ----------------------------
BEGIN;
INSERT INTO `c_common_dictionary` VALUES (1, 'NATION', '民族', '民族', b'1', b'0', 1, '2019-06-01 09:42:50', 1, '2019-06-01 09:42:54');
INSERT INTO `c_common_dictionary` VALUES (2, 'POSITION_STATUS', '在职状态', NULL, b'1', b'0', 1, '2019-06-04 11:37:15', 1, '2019-06-04 11:37:15');
INSERT INTO `c_common_dictionary` VALUES (3, 'EDUCATION', '学历', NULL, b'1', b'0', 1, '2019-06-04 11:33:52', 1, '2019-06-04 11:33:52');
INSERT INTO `c_common_dictionary` VALUES (614106494530486337, 'EDUCATION2', '测试', '测试', b'1', b'0', 0, '2019-08-22 14:39:58', 0, '2019-08-22 14:39:58');
COMMIT;

-- ----------------------------
-- Table structure for c_common_dictionary_item
-- ----------------------------
DROP TABLE IF EXISTS `c_common_dictionary_item`;
CREATE TABLE `c_common_dictionary_item` (
  `id` bigint(20) NOT NULL COMMENT '字典项id',
  `dictionary_id` bigint(20) NOT NULL COMMENT '字典id',
  `dictionary_code` varchar(64) NOT NULL COMMENT '字典编码',
  `code` varchar(64) NOT NULL DEFAULT '' COMMENT '字典项编码',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '名称',
  `is_enable` bit(1) DEFAULT b'1' COMMENT '是否启用',
  `is_delete` bit(1) DEFAULT b'0' COMMENT '是否删除',
  `describe_` varchar(255) DEFAULT '' COMMENT '描述',
  `sort_value` int(11) DEFAULT '1' COMMENT '排序',
  `create_user` bigint(20) DEFAULT '0' COMMENT '创建人id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `update_user` bigint(20) DEFAULT '0' COMMENT '更新人id',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `dict_code_item_code_uniq` (`dictionary_code`,`code`) USING BTREE COMMENT '字典编码与字典项目编码联合唯一'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='字典项';

-- ----------------------------
-- Records of c_common_dictionary_item
-- ----------------------------
BEGIN;
INSERT INTO `c_common_dictionary_item` VALUES (40, 3, 'EDUCATION', 'COLLEGE', '本科', b'1', b'0', '', 2, 1, '2019-06-04 11:36:19', 1, '2019-06-04 11:36:19');
INSERT INTO `c_common_dictionary_item` VALUES (41, 3, 'EDUCATION', 'BOSHI', '博士', b'1', b'0', '', 1, 1, '2019-06-04 11:36:29', 1, '2019-06-04 11:36:29');
INSERT INTO `c_common_dictionary_item` VALUES (43, 1, 'NATION', 'mz_hanz', '汉族', b'1', b'0', '汉族', 0, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (44, 1, 'NATION', 'mz_zz', '壮族', b'1', b'0', '壮族', 1, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (45, 1, 'NATION', 'mz_mz', '满族', b'1', b'0', '满族', 2, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (46, 1, 'NATION', 'mz_hz', '回族', b'1', b'0', '回族', 3, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (47, 1, 'NATION', 'mz_miaoz', '苗族', b'1', b'0', '苗族', 4, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (48, 1, 'NATION', 'mz_wwez', '维吾尔族', b'1', b'0', '', 5, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (49, 1, 'NATION', 'mz_tjz', '土家族', b'1', b'0', '', 6, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (50, 1, 'NATION', 'mz_yz', '彝族', b'1', b'0', '', 7, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (51, 1, 'NATION', 'mz_mgz', '蒙古族', b'1', b'0', '', 8, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (52, 1, 'NATION', 'mz_zhangz', '藏族', b'1', b'0', '', 9, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (53, 1, 'NATION', 'mz_byz', '布依族', b'1', b'0', '', 10, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (54, 1, 'NATION', 'mz_dz', '侗族', b'1', b'0', '', 11, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (55, 1, 'NATION', 'mz_yaoz', '瑶族', b'1', b'0', '', 12, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (56, 1, 'NATION', 'mz_cxz', '朝鲜族', b'1', b'0', '', 13, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (57, 1, 'NATION', 'mz_bz', '白族', b'1', b'0', '', 14, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (58, 1, 'NATION', 'mz_hnz', '哈尼族', b'1', b'0', '', 15, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (59, 1, 'NATION', 'mz_hskz', '哈萨克族', b'1', b'0', '', 16, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (60, 1, 'NATION', 'mz_lz', '黎族', b'1', b'0', '', 17, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (61, 1, 'NATION', 'mz_daiz', '傣族', b'1', b'0', '', 18, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (62, 1, 'NATION', 'mz_sz', '畲族', b'1', b'0', '', 19, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (63, 1, 'NATION', 'mz_llz', '傈僳族', b'1', b'0', '', 20, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (64, 1, 'NATION', 'mz_glz', '仡佬族', b'1', b'0', '', 21, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (65, 1, 'NATION', 'mz_dxz', '东乡族', b'1', b'0', '', 22, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (66, 1, 'NATION', 'mz_gsz', '高山族', b'1', b'0', '', 23, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (67, 1, 'NATION', 'mz_lhz', '拉祜族', b'1', b'0', '', 24, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (68, 1, 'NATION', 'mz_shuiz', '水族', b'1', b'0', '', 25, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (69, 1, 'NATION', 'mz_wz', '佤族', b'1', b'0', '', 26, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (70, 1, 'NATION', 'mz_nxz', '纳西族', b'1', b'0', '', 27, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (71, 1, 'NATION', 'mz_qz', '羌族', b'1', b'0', '', 28, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (72, 1, 'NATION', 'mz_tz', '土族', b'1', b'0', '', 29, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (73, 1, 'NATION', 'mz_zlz', '仫佬族', b'1', b'0', '', 30, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (74, 1, 'NATION', 'mz_xbz', '锡伯族', b'1', b'0', '', 31, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (75, 1, 'NATION', 'mz_kehzz', '柯尔克孜族', b'1', b'0', '', 32, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (76, 1, 'NATION', 'mz_dwz', '达斡尔族', b'1', b'0', '', 33, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (77, 1, 'NATION', 'mz_jpz', '景颇族', b'1', b'0', '', 34, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (78, 1, 'NATION', 'mz_mlz', '毛南族', b'1', b'0', '', 35, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (79, 1, 'NATION', 'mz_slz', '撒拉族', b'1', b'0', '', 36, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (80, 1, 'NATION', 'mz_tjkz', '塔吉克族', b'1', b'0', '', 37, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (81, 1, 'NATION', 'mz_acz', '阿昌族', b'1', b'0', '', 38, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (82, 1, 'NATION', 'mz_pmz', '普米族', b'1', b'0', '', 39, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (83, 1, 'NATION', 'mz_ewkz', '鄂温克族', b'1', b'0', '', 40, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (84, 1, 'NATION', 'mz_nz', '怒族', b'1', b'0', '', 41, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (85, 1, 'NATION', 'mz_jz', '京族', b'1', b'0', '', 42, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (86, 1, 'NATION', 'mz_jnz', '基诺族', b'1', b'0', '', 43, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (87, 1, 'NATION', 'mz_daz', '德昂族', b'1', b'0', '', 44, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (88, 1, 'NATION', 'mz_baz', '保安族', b'1', b'0', '', 45, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (89, 1, 'NATION', 'mz_elsz', '俄罗斯族', b'1', b'0', '', 46, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (90, 1, 'NATION', 'mz_ygz', '裕固族', b'1', b'0', '', 47, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (91, 1, 'NATION', 'mz_wzbkz', '乌兹别克族', b'1', b'0', '', 48, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (92, 1, 'NATION', 'mz_mbz', '门巴族', b'1', b'0', '', 49, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (93, 1, 'NATION', 'mz_elcz', '鄂伦春族', b'1', b'0', '', 50, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (94, 1, 'NATION', 'mz_dlz', '独龙族', b'1', b'0', '', 51, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (95, 1, 'NATION', 'mz_tkez', '塔塔尔族', b'1', b'0', '', 52, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (96, 1, 'NATION', 'mz_hzz', '赫哲族', b'1', b'0', '', 53, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (97, 1, 'NATION', 'mz_lbz', '珞巴族', b'1', b'0', '', 54, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (98, 1, 'NATION', 'mz_blz', '布朗族', b'1', b'0', '', 55, 1, '2018-03-15 20:11:01', 1, '2018-03-15 20:11:04');
INSERT INTO `c_common_dictionary_item` VALUES (99, 2, 'POSITION_STATUS', 'WORKING', '在职', b'1', b'0', '', 1, 1, '2019-06-04 11:38:16', 1, '2019-06-04 11:38:16');
INSERT INTO `c_common_dictionary_item` VALUES (100, 2, 'POSITION_STATUS', 'LEAVE', '离职', b'1', b'0', '', 2, 1, '2019-06-04 11:38:50', 1, '2019-06-04 11:38:50');
INSERT INTO `c_common_dictionary_item` VALUES (614106650038501505, 614106494530486337, 'EDUCATION2', '123', '123', b'1', b'0', '123', 1, 0, '2019-08-22 14:40:35', 0, '2019-08-22 14:40:35');
COMMIT;

-- ----------------------------
-- Table structure for c_common_opt_log
-- ----------------------------
DROP TABLE IF EXISTS `c_common_opt_log`;
CREATE TABLE `c_common_opt_log` (
  `id` bigint(20) NOT NULL COMMENT '主键',
  `request_ip` varchar(50) DEFAULT '' COMMENT '操作IP',
  `type` varchar(5) DEFAULT 'OPT' COMMENT '日志类型\n#LogType{OPT:操作类型;EX:异常类型}',
  `user_name` varchar(50) DEFAULT '' COMMENT '操作人',
  `description` varchar(255) DEFAULT '' COMMENT '操作描述',
  `class_path` varchar(255) DEFAULT '' COMMENT '类路径',
  `action_method` varchar(50) DEFAULT '' COMMENT '请求方法',
  `request_uri` varchar(50) DEFAULT '' COMMENT '请求地址',
  `http_method` varchar(10) DEFAULT 'GET' COMMENT '请求类型\n#HttpMethod{GET:GET请求;POST:POST请求;PUT:PUT请求;DELETE:DELETE请求;PATCH:PATCH请求;TRACE:TRACE请求;HEAD:HEAD请求;OPTIONS:OPTIONS请求;}',
  `params` longtext COMMENT '请求参数',
  `result` longtext COMMENT '返回值',
  `ex_desc` longtext COMMENT '异常详情信息',
  `ex_detail` longtext COMMENT '异常描述',
  `start_time` timestamp NULL DEFAULT NULL COMMENT '开始时间',
  `finish_time` timestamp NULL DEFAULT NULL COMMENT '完成时间',
  `consuming_time` bigint(20) DEFAULT '0' COMMENT '消耗时间',
  `ua` varchar(500) DEFAULT '' COMMENT '浏览器',
  `create_time` datetime DEFAULT NULL,
  `create_user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  KEY `index_type` (`type`) USING BTREE COMMENT '日志类型'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC COMMENT='系统日志';

-- ----------------------------
-- Table structure for c_core_org
-- ----------------------------
DROP TABLE IF EXISTS `c_core_org`;
CREATE TABLE `c_core_org` (
  `id` bigint(20) NOT NULL COMMENT 'ID',
  `name` varchar(255) DEFAULT '' COMMENT '名称',
  `abbreviation` varchar(255) DEFAULT '' COMMENT '简称',
  `parent_id` bigint(20) DEFAULT '0' COMMENT '父ID',
  `tree_path` varchar(255) DEFAULT ',' COMMENT '树结构',
  `sort_value` int(11) DEFAULT '1' COMMENT '排序',
  `status` bit(1) DEFAULT b'1' COMMENT '状态',
  `describe_` varchar(255) DEFAULT '' COMMENT '描述',
  `create_time` datetime DEFAULT NULL,
  `create_user` bigint(20) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `update_user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  FULLTEXT KEY `FU_PATH` (`tree_path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='组织';

-- ----------------------------
-- Records of c_core_org
-- ----------------------------
BEGIN;
INSERT INTO `c_core_org` VALUES (100, '最后集团股份有限公司', '最后集团', -1, ',', 1, b'1', '初始化数据', '2019-07-10 17:02:18', 1, '2019-07-10 17:02:16', 1);
INSERT INTO `c_core_org` VALUES (101, '最后的演示集团有限公司', '最后演示集团', 100, ',100,', 1, b'1', '初始化数据', '2019-08-06 09:10:53', 1, '2019-08-06 09:10:55', 1);
INSERT INTO `c_core_org` VALUES (102, '333', '333', 101, ',100,101,', 1, b'1', '', NULL, NULL, NULL, NULL);
INSERT INTO `c_core_org` VALUES (103, '111', '111', -1, ',', 1, b'1', '', NULL, NULL, NULL, NULL);
INSERT INTO `c_core_org` VALUES (104, '222-1', '', 103, ',103,', 1, b'1', '', NULL, NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for c_core_station
-- ----------------------------
DROP TABLE IF EXISTS `c_core_station`;
CREATE TABLE `c_core_station` (
  `id` bigint(20) NOT NULL COMMENT 'ID',
  `name` varchar(255) DEFAULT '' COMMENT '名称',
  `org_id` bigint(20) DEFAULT '0' COMMENT '组织ID\n#c_core_org',
  `sort_value` int(11) DEFAULT '1' COMMENT '排序',
  `status` bit(1) DEFAULT b'1' COMMENT '状态',
  `describe_` varchar(255) DEFAULT '' COMMENT '描述',
  `create_time` datetime DEFAULT NULL,
  `create_user` bigint(20) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `update_user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='岗位';

-- ----------------------------
-- Records of c_core_station
-- ----------------------------
BEGIN;
INSERT INTO `c_core_station` VALUES (100, '总经理', 100, 1, b'1', '总经理', '2019-07-10 17:03:03', 1, '2019-07-10 17:03:06', 1);
INSERT INTO `c_core_station` VALUES (101, '演示岗位', 101, 1, b'1', '演示岗位', '2019-07-22 17:07:55', 1, '2019-07-22 17:07:55', 1);
INSERT INTO `c_core_station` VALUES (602909772781453409, '岗位2-1', 101, 1, b'1', NULL, '2019-07-22 17:08:12', 1, '2019-07-22 17:08:12', 1);
INSERT INTO `c_core_station` VALUES (602909822567841953, '岗位2-1-1', 102, 1, b'1', NULL, '2019-07-22 17:08:23', 1, '2019-07-22 17:08:23', 1);
INSERT INTO `c_core_station` VALUES (602909879794925793, '岗位3', 100, 1, b'1', NULL, '2019-07-22 17:08:37', 1, '2019-07-22 17:08:37', 1);
INSERT INTO `c_core_station` VALUES (602909916671246625, '岗位3-1', 101, 1, b'1', NULL, '2019-07-22 17:08:46', 1, '2019-07-22 17:08:46', 1);
INSERT INTO `c_core_station` VALUES (602909967065809249, '岗位2-2', 104, 1, b'1', NULL, '2019-07-22 17:08:58', 1, '2019-07-22 17:08:58', 1);
COMMIT;

-- ----------------------------
-- Table structure for m_product
-- ----------------------------
DROP TABLE IF EXISTS `m_product`;
CREATE TABLE `m_product` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `stock` int(11) DEFAULT NULL COMMENT '库存',
  `create_time` datetime DEFAULT NULL,
  `create_user` bigint(20) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `update_user` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品';

-- ----------------------------
-- Records of m_product
-- ----------------------------
BEGIN;
INSERT INTO `m_product` VALUES (585823974982680865, '111', 1, '2019-08-20 14:12:51', NULL, NULL, NULL);
COMMIT;

-- ----------------------------
-- Table structure for undo_log
-- ----------------------------
DROP TABLE IF EXISTS `undo_log`;
CREATE TABLE `undo_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `branch_id` bigint(20) NOT NULL,
  `xid` varchar(100) NOT NULL,
  `context` varchar(128) NOT NULL,
  `rollback_info` longblob NOT NULL,
  `log_status` int(11) NOT NULL,
  `log_created` datetime NOT NULL,
  `log_modified` datetime NOT NULL,
  `ext` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;
