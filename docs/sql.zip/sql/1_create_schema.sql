CREATE DATABASE `zuihou_authority_dev` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
CREATE DATABASE `zuihou_demo_dev` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
CREATE DATABASE `zuihou_file_dev` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
CREATE DATABASE `zuihou_jobs_dev` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
CREATE DATABASE `zuihou_msgs_dev` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
